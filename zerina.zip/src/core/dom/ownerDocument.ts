export type DOMEventRoot = Document | ShadowRoot;

export type OwnedWindowTimeout = {
  ownerWindow: Window;
  id: number;
};

export type OwnedAnimationFrame = {
  ownerWindow: Window;
  id: number;
};

export function isDOMNode(value: EventTarget | null): value is Node {
  return value !== null && typeof (value as Node).nodeType === "number";
}

export function isShadowRoot(value: Node): value is ShadowRoot {
  return value.nodeType === 11 && "host" in value;
}

type SlottableNode = Node & {
  readonly assignedSlot?: HTMLSlotElement | null;
};

/**
 * Devuelve el padre efectivo de un nodo dentro del árbol compuesto.
 *
 * Un nodo distribuido pertenece primero al slot que lo presenta. Al alcanzar
 * un ShadowRoot, el recorrido continúa por su host. `parentNode` por sí solo
 * describe el árbol DOM y omite ambas relaciones, por lo que no es suficiente
 * para resolver ownership visual de portals y overlays.
 *
 * La función nunca consulta el document global y no cruza al Document de otro
 * realm. Los nodos desconectados terminan de forma segura en null.
 */
export function getComposedParentNode(
  node: Node
): Node | null {
  const ownerDocument =
    node.nodeType === 9
      ? node as Document
      : node.ownerDocument;

  /*
   * assignedSlot debe evaluarse antes que parentNode. El padre DOM de un nodo
   * distribuido sigue en light DOM, mientras que su padre compuesto es el slot
   * mediante el cual participa en el shadow tree.
   */
  const assignedSlot =
    (node as SlottableNode)
      .assignedSlot ??
    null;

  if (
    assignedSlot &&
    assignedSlot.ownerDocument ===
      ownerDocument
  ) {
    return assignedSlot;
  }

  /*
   * Un ShadowRoot no tiene parentNode. Su continuación dentro del árbol
   * compuesto es el host que lo presenta en el documento propietario.
   */
  if (isShadowRoot(node)) {
    return node.host.ownerDocument ===
      ownerDocument
      ? node.host
      : null;
  }

  const parent =
    node.parentNode;

  if (parent) {
    const parentDocument =
      parent.nodeType === 9
        ? parent as Document
        : parent.ownerDocument;

    return parentDocument ===
      ownerDocument
      ? parent
      : null;
  }

  /*
   * Este fallback cubre nodos cuyo root compuesto es un ShadowRoot aunque no
   * expongan parentNode en el momento de la consulta.
   */
  const root =
    node.getRootNode();

  if (
    root !== node &&
    isShadowRoot(root) &&
    root.ownerDocument ===
      ownerDocument
  ) {
    return root;
  }

  return null;
}

function getOwnerDocument(
  node: Node
): Document | null {
  return node.nodeType === 9
    ? node as Document
    : node.ownerDocument;
}

/**
 * Comprueba si un nodo pertenece al subárbol compuesto de un ancestro.
 *
 * La relación incluye al propio ancestro, igual que Node.contains(). A
 * diferencia de contains(), el recorrido reconoce assignedSlot y continúa
 * desde un ShadowRoot hacia su host.
 *
 * Ambos nodos deben pertenecer al mismo Document. La función no cruza hacia
 * documentos embebidos ni consulta el document global.
 */
export function isComposedDescendantOf(
  node: Node,
  ancestor: Node
): boolean {
  const nodeDocument =
    getOwnerDocument(node);

  const ancestorDocument =
    getOwnerDocument(ancestor);

  if (
    !nodeDocument ||
    nodeDocument !==
      ancestorDocument
  ) {
    return false;
  }

  let current:
    Node | null =
    node;

  while (current) {
    if (current === ancestor) {
      return true;
    }

    current =
      getComposedParentNode(
        current
      );
  }

  return false;
}

export interface GetDeepActiveElementOptions {
  /**
   * Permite continuar desde un iframe hacia su Document cuando el acceso
   * same-origin está disponible.
   *
   * El valor por defecto es false para conservar la frontera documental del
   * root recibido.
   */
  traverseIframes?: boolean;
}

function isOwnedHTMLElement(
  element: Element
): element is HTMLElement {
  const ownerWindow =
    element.ownerDocument
      .defaultView;

  /*
   * El constructor debe proceder del realm propietario. Un HTMLElement de un
   * iframe no es instancia del HTMLElement global de la ventana principal.
   */
  return !!(
    ownerWindow &&
    element instanceof
      ownerWindow.HTMLElement
  );
}

/**
 * Obtiene el elemento activo profundo dentro del root recibido.
 *
 * A diferencia de Document.activeElement, continúa a través de shadow roots
 * abiertos. Por defecto permanece dentro del mismo Document y nunca consulta
 * el document global.
 *
 * traverseIframes permite conservar explícitamente flujos que necesitan entrar
 * en iframes same-origin. Un iframe cross-origin, inaccesible o sin active
 * element permanece como el último elemento activo observable.
 */
export function getDeepActiveElement(
  initialRoot: DOMEventRoot,
  {
    traverseIframes = false,
  }: GetDeepActiveElementOptions = {}
): HTMLElement | null {
  let root:
    DOMEventRoot =
    initialRoot;

  const visitedRoots =
    new Set<DOMEventRoot>();

  while (
    !visitedRoots.has(root)
  ) {
    visitedRoots.add(root);

    const active =
      root.activeElement;

    if (
      !active ||
      !isOwnedHTMLElement(
        active
      )
    ) {
      return null;
    }

    const shadowRoot =
      active.shadowRoot;

    if (
      shadowRoot?.activeElement
    ) {
      root = shadowRoot;
      continue;
    }

    if (
      traverseIframes &&
      active.tagName ===
        "IFRAME"
    ) {
      try {
        const frameDocument =
          (
            active as
              HTMLIFrameElement
          ).contentDocument;

        if (
          frameDocument
            ?.activeElement
        ) {
          root =
            frameDocument;

          continue;
        }
      } catch {
        /*
         * Un iframe cross-origin no expone su Document. En ese caso el frame
         * sigue siendo el elemento activo más profundo que podemos observar.
         */
      }
    }

    return active;
  }

  return null;
}


export function getNodeEventRoot(node: Node): DOMEventRoot {
  const root = node.getRootNode();

  if (isShadowRoot(root)) {
    return root;
  }

  if (root.nodeType === 9) {
    return root as Document;
  }

  const ownerDocument = node.ownerDocument;

  if (!ownerDocument) {
    throw new Error("A DOM event root requires an owning Document.");
  }

  return ownerDocument;
}

export function isEventInsideNode(event: Event, node: Node): boolean {
  let path:
    EventTarget[] | null =
    null;

  if (
    typeof event.composedPath ===
      "function"
  ) {
    try {
      const nextPath =
        event.composedPath();

      if (
        Array.isArray(nextPath) &&
        nextPath.length > 0
      ) {
        path = nextPath;
      }
    } catch {
      /*
       * Eventos instrumentados pueden exponer composedPath sin poder
       * ejecutarlo. Solo entonces se recurre al target estructural.
       */
    }
  }

  /*
   * Una ruta compuesta utilizable es autoritativa. Si no alcanza al nodo, no
   * debe reinterpretarse el evento mediante el árbol DOM ordinario.
   */
  if (path) {
    return path.includes(node);
  }

  return (
    isDOMNode(event.target) &&
    isComposedDescendantOf(
      event.target,
      node
    )
  );
}

export function setOwnedWindowTimeout(
  ownerWindow: Window,
  callback: () => void,
  delay: number
): OwnedWindowTimeout {
  return {
    ownerWindow,
    id: ownerWindow.setTimeout(callback, delay),
  };
}

export function clearOwnedWindowTimeout(
  timeout: OwnedWindowTimeout | null
): void {
  if (timeout) {
    timeout.ownerWindow.clearTimeout(timeout.id);
  }
}

export function requestOwnedAnimationFrame(
  ownerWindow: Window,
  callback: FrameRequestCallback
): OwnedAnimationFrame {
  return {
    ownerWindow,
    id: ownerWindow.requestAnimationFrame(callback),
  };
}

export function cancelOwnedAnimationFrame(
  frame: OwnedAnimationFrame | null
): void {
  if (frame) {
    frame.ownerWindow.cancelAnimationFrame(frame.id);
  }
}
